
modVersion = "0.3.7" --version of control data, only updated when control.lua data handling changes in a major way
modName = "beltSorter" -- required prefix for all ui name components which can be clicked
fullModName = "beltSorter" -- required for logging and prototypes


libLog.debug_master = true
--libLog.testing = true -- enables player printing of every log, sets log level to info
--libLog.debug_level = 1  -- 1=info 2=warn 3=error